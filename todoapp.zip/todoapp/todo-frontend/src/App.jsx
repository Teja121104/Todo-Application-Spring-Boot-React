import { useEffect, useState } from "react";
import axios from "axios";

// PARTICLES
import Particles from "react-tsparticles";
import { loadFull } from "tsparticles";

import "./App.css";

const API_URL = "http://localhost:8081/api/todos";

export default function App() {
  const [todos, setTodos] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [darkMode, setDarkMode] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editTitle, setEditTitle] = useState("");
  const [editDescription, setEditDescription] = useState("");

  const loadTodos = async () => {
    const res = await axios.get(API_URL);
    setTodos(res.data);
  };

  useEffect(() => {
    loadTodos();
  }, []);

  const addTodo = async () => {
    if (!title.trim()) return;
    await axios.post(API_URL, {
      title,
      description,
      completed: false,
    });
    setTitle("");
    setDescription("");
    loadTodos();
  };

  const toggleTodo = async (todo) => {
    await axios.put(`${API_URL}/${todo.id}`, {
      ...todo,
      completed: !todo.completed,
    });
    loadTodos();
  };

  const deleteTodo = async (id) => {
    await axios.delete(`${API_URL}/${id}`);
    loadTodos();
  };

  const exportCSV = () => {
    const headers = ["Title", "Description", "Completed"];
    const rows = todos.map((t) => [
      t.title,
      t.description,
      t.completed ? "Yes" : "No",
    ]);
    const csvContent =
      "data:text/csv;charset=utf-8," +
      [headers, ...rows].map((e) => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "todos.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredTodos = todos
    .filter((todo) => {
      const matchesSearch =
        todo.title.toLowerCase().includes(search.toLowerCase()) ||
        (todo.description || "").toLowerCase().includes(search.toLowerCase());
      const matchesFilter =
        filter === "all" ||
        (filter === "completed" && todo.completed) ||
        (filter === "pending" && !todo.completed);
      return matchesSearch && matchesFilter;
    })
    .sort((a, b) => a.completed - b.completed);

  const highlightText = (text) => {
    if (!search) return text;
    const regex = new RegExp(`(${search})`, "gi");
    return text.split(regex).map((part, i) =>
      regex.test(part) ? (
        <mark key={i} className="highlight">
          {part}
        </mark>
      ) : (
        part
      ),
    );
  };

  const startEditing = (todo) => {
    setEditingId(todo.id);
    setEditTitle(todo.title);
    setEditDescription(todo.description);
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditTitle("");
    setEditDescription("");
  };

  const saveEdit = async (id) => {
    if (!editTitle.trim()) return;
    await axios.put(`${API_URL}/${id}`, {
      title: editTitle,
      description: editDescription,
      completed: todos.find((t) => t.id === id).completed,
    });
    cancelEditing();
    loadTodos();
  };

  const particlesInit = async (main) => {
    await loadFull(main);
  };

  const particlesOptions = {
    fpsLimit: 60,
    particles: {
      number: { value: 70 },
      color: { value: ["#4f46e5", "#6366f1", "#8b5cf6"] },
      shape: { type: "circle" },
      size: { value: { min: 2, max: 4 } },
      move: { enable: true, speed: 1 },
      links: {
        enable: true,
        distance: 120,
        color: "#4f46e5",
        opacity: 0.4,
        width: 1,
      },
    },
    detectRetina: true,
  };

  return (
    <div className={`app ${darkMode ? "dark" : "light"}`}>
      <Particles
        init={particlesInit}
        options={particlesOptions}
        className="particles-bg"
      />

      <header className="header">
        <div className="logo-container">
          <img
            src="https://i.ibb.co/0VKZT0TV/images.png"
            alt="logo"
            className="logo"
          />
          <h1>Todo Manager</h1>
        </div>

        <button className="mode-toggle" onClick={() => setDarkMode(!darkMode)}>
          {darkMode ? "Light Mode" : "Dark Mode"}
        </button>
      </header>

      <section className="section">
        <div className="card centered">
          <h2>Add New Task</h2>

          <input
            type="text"
            placeholder="Task title *"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />

          <textarea
            placeholder="Task description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />

          <button className="primary" onClick={addTodo}>
            Add Task
          </button>
        </div>
      </section>

      <section className="section">
        <div className="card">
          <div className="list-header">
            <h2>Your Tasks</h2>

            <div className="controls">
              <input
                type="text"
                placeholder="Search..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />

              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
              >
                <option value="all">All</option>
                <option value="completed">Completed</option>
                <option value="pending">Pending</option>
              </select>

              <button className="export-btn" onClick={exportCSV}>
                Export CSV
              </button>
            </div>
          </div>

          {filteredTodos.length === 0 ? (
            <p className="empty">No tasks found</p>
          ) : (
            filteredTodos.map((todo) => (
              <div
                key={todo.id}
                className={`todo ${todo.completed ? "completed" : ""}`}
              >
                <div className="todo-content">
                  {editingId === todo.id ? (
                    <>
                      <input
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        className="edit-input"
                      />
                      <textarea
                        value={editDescription}
                        onChange={(e) => setEditDescription(e.target.value)}
                        className="edit-textarea"
                      />
                    </>
                  ) : (
                    <>
                      <h3>{highlightText(todo.title)}</h3>
                      <p>{highlightText(todo.description)}</p>
                      {todo.completed && (
                        <span className="badge">Completed</span>
                      )}
                    </>
                  )}
                </div>

                <div className="actions">
                  {editingId === todo.id ? (
                    <>
                      <button
                        onClick={() => saveEdit(todo.id)}
                        className="primary"
                      >
                        Save
                      </button>
                      <button onClick={cancelEditing} className="danger">
                        Cancel
                      </button>
                    </>
                  ) : (
                    <>
                      <button onClick={() => toggleTodo(todo)}>
                        {todo.completed ? "Undo" : "Done"}
                      </button>
                      <button onClick={() => startEditing(todo)}>Edit</button>
                      <button
                        className="danger"
                        onClick={() => deleteTodo(todo.id)}
                      >
                        Delete
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </section>

      <footer className="footer">
        © 2026 Todo Manager | Professional Full-Stack Project
      </footer>
    </div>
  );
}
